package org.demo.zach.htmxapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HtmxappApplication {

	public static void main(String[] args) {
		SpringApplication.run(HtmxappApplication.class, args);
	}

}
